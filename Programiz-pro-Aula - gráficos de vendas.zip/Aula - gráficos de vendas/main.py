import pandas as pd
import matplotlib.pyplot as plt

# Carregar o CSV
df = pd.read_csv('dados.csv')

# Mostrar as primeiras linhas
print(df.head())

# Verificar se existe dados ausentes
print(df.isnull().sum())

# Eliminar as linhas com dados ausentes
df = df.dropna()

# Verificar os tipos de dados das colunas
print(df.dtypes)

# Estatísticas descritivas
print(df.describe())

# Agrupar os dados por produto e somar a venda
vendas_por_produto = df.groupby('produto')['preco_unitario'].sum()
print(vendas_por_produto)

plt.bar(df['produto'],df['total_vendas'], color='blue')
plt.title('VENDAS PRODUTO')
plt.xlabel('Produto')
plt.ylabel('Total de vendas')
plt.show()

# linhas - plot

plt.plot(df['produto'],df['total_vendas'], color='blue')
plt.title('VENDAS PRODUTO')
plt.xlabel('Produto')
plt.ylabel('Total de vendas')
plt.show()

# dispersão - scatter - Mostra a relação entre duas variáveis

plt.scatter(df['produto'],df['total_vendas'], color='blue')
plt.title('VENDAS PRODUTO')
plt.xlabel('Produto')
plt.ylabel('Total de vendas')
plt.show()

# pizza - pie - Mostra a proporção em relação ao todo
N = df.head()
plt.pie(df['preco_unitario'], labels = df['produto'], autopct = '%1.1f')
plt.title('GRÁFICO DE PIZZA')
plt.show()

# QUAIS PRODUTOS TEM AS MAIORES VENDAS TOTAIS?

# AS VENDAS AUMENTAM COM O TEMPO?

# EXISTE RELAÇÃO ENTRE O PREÇO UNITÁRIO E O TOTAL DE VENDA?

# QUAIS DIAS DA SEMANA TEM MAIORES VENDAS?