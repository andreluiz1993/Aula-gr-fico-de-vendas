import pandas as pd
import matplotlib.pyplot as plt

# Carregar o CSV
df = pd.read_csv('dados2.csv')

# Mostrar as primeiras linhas
print(df.head())

# linhas - plot

plt.plot(df['mes'],df['venda'], color='red')
plt.title('Vendas da loja')
plt.xlabel('Meses')
plt.ylabel('Vendas')
plt.show()